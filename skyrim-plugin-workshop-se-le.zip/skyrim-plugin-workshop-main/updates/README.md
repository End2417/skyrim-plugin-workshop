Upload a project zip here or to the repository root, committing straight to main.
The "Import zip and build" workflow starts by itself.
