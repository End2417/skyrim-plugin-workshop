<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Plugin parsing/serialization lives in `src/lib/esp/format.ts` and runs entirely in the browser; keep it UI-free so it stays testable.
- Records keep their original bytes until edited (`markDirty` before any mutation), so untouched records save byte-for-byte identical.
- Field names/layouts per record type live in `src/lib/esp/defs.ts` (hand-written from TES5Edit's wbDefinitionsTES5.pas); `decode.ts` turns them into editable rows. Unknown subrecords must still fall back to raw text/hex so nothing becomes uneditable.
- Browser download dispatch and delayed URL cleanup live in a UI-free helper; anchor clicks cannot confirm disk writes, so download feedback must not clear unsaved edits or claim completion.
- Offline support uses vite-plugin-pwa (generateSW) writing `sw.js` into the client environment's outDir; `src/lib/pwa/register.ts` is the only registrar and `src/lib/pwa/guard.ts` blocks dev, iframes, Lovable preview hosts and `?sw=off`, so previews never serve stale cached code. Pages are NetworkFirst, never precached.
- Extracting edited records into a standalone .esp lives in `src/lib/esp/extract.ts` (UI-free). The new file lists the source plugin as its last master so FormIDs stay unchanged and override the originals; localized string IDs cannot be reused and are replaced by typed text.
