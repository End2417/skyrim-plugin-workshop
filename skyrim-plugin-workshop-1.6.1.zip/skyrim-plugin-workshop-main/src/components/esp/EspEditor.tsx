import { useEffect, useMemo, useRef, useState } from "react";
import { AlertCircle, ArrowDown, ArrowLeftRight, ArrowUp, Download, FileCode, FolderCog, FolderOpen, GitCompare, GitMerge, Info, ListChecks, PackageOpen, Redo2, ShieldCheck, SlidersHorizontal, Undo2, Wrench, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import type { DecodeContext } from "@/lib/esp/decode";
import { backupOriginal, downloadPlugin } from "@/lib/esp/download";
import { autoBackupEnabled, BackupLedger } from "@/lib/esp/backup";
import { chooseLanguage, listArchiveStrings, parseBsa, pluginBase, readBsaFile, stringsFileName } from "@/lib/esp/bsa";
import { isArchiveFileName } from "@/lib/esp/masterImport";
import { APP_TITLE } from "@/lib/appInfo";
import { onFileOpened, readOpenedFile, takePendingFile, type OpenedFile } from "@/lib/native/espFiles";
import { buildSearchIndex, filterIndex, hasFieldQuery, searchIndex, type SearchIndex } from "@/lib/esp/search";
import { applyDraft, clearDraft, fileSignature, loadDraft, makeDraft, saveDraft, type Draft } from "@/lib/esp/draft";
import {
  forgetStringFiles,
  mergeStringTables,
  parseStringsFile,
  recallStringFiles,
  rememberStringFiles,
  setActiveStrings,
  type StringTable,
} from "@/lib/esp/strings";
import { History } from "@/lib/esp/history";
import { revertWithHistory } from "@/lib/esp/records";
import {
  buildFormIdIndex,
  countRecords,
  describeGroup,
  fileInfo,
  getDisplayName,
  getEditorId,
  hex8,
  parseEsp,
  serializeEsp,
  walkRecords,
  type EspFile,
  type EspGroup,
  type EspRecord,
} from "@/lib/esp/format";
import { AboutDialog, useFirstLaunchAbout } from "./AboutDialog";
import { UpdateDialog, useUpdateCheck } from "./UpdateDialog";
import { ChangesDialog } from "./ChangesDialog";
import { CheckDialog } from "./CheckDialog";
import { CompareDialog } from "./CompareDialog";
import { ScriptsDialog } from "./ScriptsDialog";
import { HeaderDialog } from "./HeaderDialog";
import { HealthDialog } from "./HealthDialog";
import { LoadOrderDialog } from "./LoadOrderDialog";
import { MergeDialog } from "./MergeDialog";
import { NewRecordDialog } from "./NewRecordDialog";
import { BulkEditDialog } from "./BulkEditDialog";
import { ConvertDialog } from "./ConvertDialog";
import { SetupDialog } from "./SetupDialog";
import { isSetupDone, markSetupDone } from "@/lib/esp/setupState";
import { detectEdition } from "@/lib/esp/convert";
import { nextSort, sortRecords, type SortColumn, type SortState } from "@/lib/esp/sort";
import { ExtractDialog } from "./ExtractDialog";
import { RecordRow, RecordTree, TREE_COLS } from "./RecordTree";
import { RecordFinderContext, type RecordFinder } from "./recordPicker";
import { describeMasterEntry, findMasterEntry, searchMasterNames, type MasterNames } from "@/lib/esp/masterNames";
import { listRememberedMasters, recallMasterNames } from "@/lib/esp/masterStore";
import { RecordView } from "./RecordView";
import { SaveFolderDialog, saveFolderSupported } from "./SaveFolderDialog";

const MAX_RESULTS = 500;
/** Rows drawn at once; the rest are one tap away, so a broad search stays quick to show. */
const PAGE_SIZE = 100;

export function EspEditor() {
  const [file, setFile] = useState<EspFile | null>(null);
  const [selected, setSelected] = useState<EspRecord | null>(null);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());
  const [error, setError] = useState<string | null>(null);
  const [saveFeedback, setSaveFeedback] = useState<{ failed: boolean; filename: string; detail?: string; savedTo?: string; backup?: string; backupError?: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [extractOpen, setExtractOpen] = useState(false);
  const [checkOpen, setCheckOpen] = useState(false);
  const [scriptsOpen, setScriptsOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);
  const [headerOpen, setHeaderOpen] = useState(false);
  const [healthOpen, setHealthOpen] = useState(false);
  const [orderOpen, setOrderOpen] = useState(false);
  const [mergeOpen, setMergeOpen] = useState(false);
  const [newOpen, setNewOpen] = useState(false);
  /** The record the "new record" dialog copies, or null to make an empty one. */
  const [copySource, setCopySource] = useState<EspRecord | null>(null);
  // Undo and redo for edits, created and deleted records (see lib/esp/history.ts)
  const [history] = useState(() => new History());
  // The file exactly as it was opened, for "back up the original before saving". It shares memory with the parsed records.
  const originalRef = useRef<{ name: string; bytes: Uint8Array } | null>(null);
  const backupLedger = useRef(new BackupLedger());
  const [convertOpen, setConvertOpen] = useState(false);
  const [setupOpen, setSetupOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [sort, setSort] = useState<SortState | null>(null);
  const [folderOpen, setFolderOpen] = useState(false);
  const [native, setNative] = useState(false); // known only on the device, so set after the first render
  const searchIndexRef = useRef<SearchIndex | null>(null);
  const [indexedFile, setIndexedFile] = useState<EspFile | null>(null);
  const [shown, setShown] = useState(PAGE_SIZE);
  const [aboutOpen, setAboutOpen] = useFirstLaunchAbout();
  // Newer release on GitHub? Only in the Android app
  const update = useUpdateCheck(native);
  const [changesOpen, setChangesOpen] = useState(false);
  const [strings, setStrings] = useState<StringTable | null>(null);
  const [stringsMsg, setStringsMsg] = useState<string | null>(null);
  const stringPartsRef = useRef<Map<string, { name: string; strings: Map<number, string>; bytes: Uint8Array }>>(new Map());
  const stringsInputRef = useRef<HTMLInputElement>(null);
  const [pendingDraft, setPendingDraft] = useState<Draft | null>(null);
  const [draftNote, setDraftNote] = useState<string | null>(null);
  const sigRef = useRef<string | null>(null);
  const fileRef = useRef<EspFile | null>(null);
  const [modified, setModified] = useState(false);
  const [filterId, setFilterId] = useState("");
  const [filterEdid, setFilterEdid] = useState("");
  const [filterName, setFilterName] = useState("");
  const [results, setResults] = useState<EspRecord[] | null>(null);
  const [rev, setRev] = useState(0);
  const [indexRev, setIndexRev] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  const index = useMemo(() => (file ? buildFormIdIndex(file) : new Map<number, EspRecord>()), [file, indexRev]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const info = useMemo(() => (file ? fileInfo(file) : { localized: false, masters: [] }), [file, rev]);

  // Read once per opened file: it only looks at record headers, so it is cheap, but it need not rerun on every edit.
  const edition = useMemo(() => (file ? detectEdition(file).edition : null), [file]);

  // First launch: offer to set up Skyrim's own files (skipped if masters were already added some other way)
  useEffect(() => {
    if (isSetupDone()) return;
    let live = true;
    void listRememberedMasters().then((list) => {
      if (!live) return;
      if (list.length > 0) markSetupDone();
      else setSetupOpen(true);
    });
    return () => {
      live = false;
    };
  }, []);

  // Names of the records in the masters the app remembers, by master slot, so references into them can be shown and searched
  const masterNamesRef = useRef<(MasterNames | null)[]>([]);
  const [, setMasterNamesRev] = useState(0);
  useEffect(() => {
    masterNamesRef.current = [];
    setMasterNamesRev((n) => n + 1);
    if (!file) return;
    let live = true;
    void Promise.all(fileInfo(file).masters.map((m) => recallMasterNames(m))).then((list) => {
      if (!live) return;
      masterNamesRef.current = list;
      setMasterNamesRev((n) => n + 1);
    });
    return () => {
      live = false;
    };
    // checkOpen, setupOpen: masters are added in those dialogs, so look again when they close
  }, [file, checkOpen, setupOpen]);

  // Lets the reference editor suggest records by name: this plugin's first, then its remembered masters'
  const findRecords: RecordFinder = async (query, limit, cancelled) => {
    const ix = searchIndexRef.current;
    if (!ix || ix.file !== fileRef.current) return null;
    const own = await searchIndex(ix, query, limit, cancelled);
    if (!own) return null;
    const ids = own.map((r) => r.formId >>> 0);
    const seen = new Set(ids);
    masterNamesRef.current.forEach((m, slot) => {
      if (!m) return;
      for (const i of searchMasterNames(m, query, limit)) {
        if (ids.length >= limit) return;
        const id = ((slot << 24) | m.ids[i]!) >>> 0;
        if (!seen.has(id)) {
          seen.add(id);
          ids.push(id);
        }
      }
    });
    return ids;
  };

  // Search results in the chosen order (the tree sorts each group itself)
  // eslint-disable-next-line react-hooks/exhaustive-deps -- `rev` is how edits made in place are noticed
  const orderedResults = useMemo(() => (results && sort ? sortRecords(results, sort, info.localized) : results), [results, sort, info.localized, rev]);

  const ctx: DecodeContext = {
    localized: info.localized,
    resolveFormId: (id) => {
      if (id === 0) return "NULL - Null Reference [00000000]";
      const r = index.get(id >>> 0);
      if (r) {
        const e = getEditorId(r);
        const n = getDisplayName(r, info.localized);
        return `${e ?? ""}${n ? ` "${n}"` : ""} [${r.type}:${hex8(id)}]`.trim();
      }
      const hi = id >>> 24;
      if (hi < info.masters.length) {
        const m = masterNamesRef.current[hi];
        const at = m ? findMasterEntry(m, id & 0xffffff) : -1;
        if (m && at >= 0) return describeMasterEntry(m, at, id);
        return `[${hex8(id)}] from ${info.masters[hi]}`;
      }
      return `[${hex8(id)}] (not found in this file)`;
    },
  };

  const changed = (opts?: { reindex?: boolean }) => {
    setSaveFeedback(null);
    setModified(true);
    setRev((r) => r + 1);
    if (opts?.reindex) setIndexRev((r) => r + 1);
  };

  // ----- strings files (names and descriptions of localized plugins such as Skyrim.esm) -----
  function applyStrings(table: StringTable | null, target: EspFile | null = file) {
    setActiveStrings(table);
    setStrings(table);
    if (target) for (const r of walkRecords(target.nodes)) r.nameCache = undefined; // names are looked up again
    setIndexRev((n) => n + 1);
    setRev((n) => n + 1);
  }

  function rebuildStrings(target: EspFile | null = file) {
    const parts = [...stringPartsRef.current.values()];
    applyStrings(parts.length ? mergeStringTables(parts) : null, target);
  }

  async function recallStrings(target: EspFile) {
    const saved = await recallStringFiles(target.name);
    if (!saved || fileRef.current !== target) return;
    try {
      for (const f of saved) stringPartsRef.current.set(f.name, { name: f.name, strings: parseStringsFile(f.name, f.bytes), bytes: f.bytes });
      rebuildStrings(target);
      setStringsMsg("Names restored from the strings files you loaded before.");
    } catch {
      /* stored files unreadable: the person can load them again */
    }
  }

  async function loadStringFiles(list: File[]) {
    if (!file || list.length === 0) return;
    setStringsMsg(null);
    try {
      const notes: string[] = [];
      for (const f of list) {
        const bytes = new Uint8Array(await f.arrayBuffer());
        if (isArchiveFileName(f.name)) {
          // A BSA (such as Skyrim - Interface.bsa): take this plugin's strings files out of it
          const archive = parseBsa(bytes);
          const mine = listArchiveStrings(archive).filter((s) => s.plugin === pluginBase(file.name));
          const language = chooseLanguage(mine.map((s) => s.language));
          const picked = mine.filter((s) => s.language === language);
          if (picked.length === 0) notes.push(`${f.name} has no strings files for ${file.name}.`);
          for (const s of picked) {
            const name = stringsFileName(file.name, s);
            const data = readBsaFile(archive, s.entry);
            stringPartsRef.current.set(name, { name, strings: parseStringsFile(name, data), bytes: data });
          }
          continue;
        }
        stringPartsRef.current.set(f.name, { name: f.name, strings: parseStringsFile(f.name, bytes), bytes });
      }
      rebuildStrings();
      const parts = [...stringPartsRef.current.values()];
      const kept = parts.length > 0 && (await rememberStringFiles(file.name, parts.map((p) => ({ name: p.name, bytes: p.bytes }))));
      setStringsMsg(
        parts.length === 0
          ? notes.join(" ")
          : `Loaded ${parts.length} strings file${parts.length === 1 ? "" : "s"}.${kept ? " They will be remembered on this device." : ""}${notes.length ? ` ${notes.join(" ")}` : ""}`,
      );
    } catch (e) {
      setStringsMsg(e instanceof Error ? e.message : String(e));
    }
  }

  function forgetStrings() {
    stringPartsRef.current = new Map();
    rebuildStrings();
    if (file) void forgetStringFiles(file.name);
    setStringsMsg("Strings files forgotten.");
  }

  // ----- undo, drafts -----
  function revert(r: EspRecord) {
    if (file && revertWithHistory(history, file, r)) changed({ reindex: true });
  }

  /** After an undo or redo the selected record may have been made or removed by it. */
  function stillInFile(r: EspRecord): boolean {
    if (!file) return false;
    return r.parent ? r.parent.children.includes(r) : file.nodes.includes(r);
  }

  function undo() {
    if (!history.undo()) return;
    changed({ reindex: true });
    if (file && selected && !stillInFile(selected)) setSelected(file.nodes[0] as EspRecord);
  }

  function redo() {
    if (!history.redo()) return;
    changed({ reindex: true });
    if (file && selected && !stillInFile(selected)) setSelected(file.nodes[0] as EspRecord);
  }

  function created(r: EspRecord) {
    changed({ reindex: true });
    select(r, true);
  }

  function restoreDraft() {
    if (!file || !pendingDraft) return;
    const { applied, missing } = applyDraft(file, pendingDraft);
    setPendingDraft(null);
    history.clear(); // a restored draft is the starting point, not a step to undo
    changed({ reindex: true });
    setDraftNote(`Restored ${applied} change${applied === 1 ? "" : "s"}${missing ? ` (${missing} no longer matched this file)` : ""}.`);
  }

  function discardDraft() {
    if (sigRef.current) clearDraft(sigRef.current);
    setPendingDraft(null);
  }

  async function openFile(f: File) {
    await openBytes(async () => new Uint8Array(await f.arrayBuffer()), f.name);
  }

  async function openBytes(load: () => Promise<Uint8Array>, name: string) {
    setLoading(true);
    setError(null);
    setSaveFeedback(null);
    try {
      const bytes = await load();
      const parsed = parseEsp(bytes, name);
      originalRef.current = { name, bytes };
      history.clear();
      sigRef.current = fileSignature(name, bytes.length);
      setPendingDraft(loadDraft(sigRef.current));
      setDraftNote(null);
      stringPartsRef.current = new Map();
      setActiveStrings(null);
      setStrings(null);
      setStringsMsg(null);
      if (fileInfo(parsed).localized) void recallStrings(parsed);
      setFile(parsed);
      setSelected(parsed.nodes[0] as EspRecord);
      setExpanded(new Set());
      setModified(false);
      setResults(null);
      setFilterId("");
      setFilterEdid("");
      setFilterName("");
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  async function save() {
    if (!file) return;
    setSaveFeedback(null);
    try {
      const bytes = serializeEsp(file);
      // Before the first save of this file, keep a copy of the original next to it (Android app only)
      let backup: string | undefined;
      let backupError: string | undefined;
      const original = originalRef.current;
      if (original && autoBackupEnabled() && !backupLedger.current.has(original.name, original.bytes.length)) {
        try {
          const where = await backupOriginal(original.bytes, original.name);
          if (where) {
            backup = where;
            backupLedger.current.add(original.name, original.bytes.length);
          }
        } catch (e) {
          backupError = e instanceof Error ? e.message : String(e);
        }
      }
      const savedTo = await downloadPlugin(bytes, file.name);
      setSaveFeedback({ failed: false, filename: file.name, ...(savedTo ? { savedTo } : {}), ...(backup ? { backup } : {}), ...(backupError ? { backupError } : {}) });
      // A dispatched click is not proof that the file was saved. Keep edits
      // marked unsaved until a confirmed save mechanism is available.
    } catch (e) {
      setSaveFeedback({ failed: true, filename: file.name, detail: e instanceof Error ? e.message : String(e) });
    }
  }

  function select(r: EspRecord, reveal = false) {
    setSelected(r);
    if (reveal) {
      const next = new Set(expanded);
      for (let g: EspGroup | null = r.parent; g; g = g.parent) next.add(g.uid);
      setExpanded(next);
    }
    if (window.innerWidth < 1024) requestAnimationFrame(() => panelRef.current?.scrollIntoView({ behavior: "smooth" }));
  }

  function toggle(uid: number) {
    const next = new Set(expanded);
    if (next.has(uid)) next.delete(uid);
    else next.add(uid);
    setExpanded(next);
  }

  // Prepare the search in the background as soon as a file is open (and again after records
  // are added or removed), so typing never waits on it.
  useEffect(() => {
    if (!file) {
      searchIndexRef.current = null;
      setIndexedFile(null);
      return;
    }
    if (searchIndexRef.current?.file !== file) {
      searchIndexRef.current = null;
      setIndexedFile(null);
    }
    let cancelled = false;
    void buildSearchIndex(file, info.localized, () => cancelled).then((ix) => {
      if (cancelled || !ix) return;
      searchIndexRef.current = ix;
      setIndexedFile(file);
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file, indexRev]);

  // Filter as you type, a moment after you stop. Runs in slices, and a newer search replaces an older one.
  useEffect(() => {
    if (!file) return;
    if (!hasFieldQuery({ formId: filterId, editorId: filterEdid, name: filterName })) {
      setResults(null);
      return;
    }
    let cancelled = false;
    const t = setTimeout(() => {
      const ix = searchIndexRef.current;
      if (!ix || ix.file !== file) return; // runs again when the index is ready
      void filterIndex(ix, { formId: filterId, editorId: filterEdid, name: filterName }, MAX_RESULTS, () => cancelled).then((res) => {
        if (cancelled || !res) return;
        setResults(res);
        setShown(PAGE_SIZE);
      });
    }, 250);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [filterId, filterEdid, filterName, file, indexedFile]);

  fileRef.current = file;

  // Autosave a draft of the edits shortly after each change, and right away when the app goes to the background
  // (Android may close it there). A draft waiting to be restored is never overwritten.
  const saveNow = () => {
    const f = fileRef.current;
    const sig = sigRef.current;
    if (!f || !sig) return;
    const draft = makeDraft(f, sig);
    if (!draft) {
      clearDraft(sig);
      setDraftNote(null);
    } else {
      const ok = saveDraft(draft);
      setDraftNote(ok ? `Draft saved ${new Date(draft.savedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "Draft too large to autosave");
    }
  };
  const saveNowRef = useRef(saveNow);
  saveNowRef.current = saveNow;

  useEffect(() => {
    if (!file || pendingDraft || rev === 0) return;
    const t = setTimeout(() => saveNowRef.current(), 1200);
    return () => clearTimeout(t);
  }, [rev, file, pendingDraft]);

  useEffect(() => {
    const flush = () => {
      if (document.visibilityState === "hidden" && !pendingDraftRef.current) saveNowRef.current();
    };
    document.addEventListener("visibilitychange", flush);
    window.addEventListener("pagehide", flush);
    return () => {
      document.removeEventListener("visibilitychange", flush);
      window.removeEventListener("pagehide", flush);
    };
  }, []);
  const pendingDraftRef = useRef(pendingDraft);
  pendingDraftRef.current = pendingDraft;

  // Undo and redo see edits as they are made. Ctrl/Cmd+Z and Ctrl/Cmd+Shift+Z (or Y) work when no text box has the focus.
  useEffect(() => {
    history.attach();
    const onKey = (e: KeyboardEvent) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;
      const k = e.key.toLowerCase();
      if (k === "z" && !e.shiftKey) {
        e.preventDefault();
        undoRef.current();
      } else if ((k === "z" && e.shiftKey) || k === "y") {
        e.preventDefault();
        redoRef.current();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      history.detach();
    };
  }, [history]);
  const undoRef = useRef(undo);
  undoRef.current = undo;
  const redoRef = useRef(redo);
  redoRef.current = redo;

  // "Open with": a plugin tapped in the Files app arrives here, both at launch and while the app is running.
  const openBytesRef = useRef(openBytes);
  openBytesRef.current = openBytes;
  const modifiedRef = useRef(modified);
  modifiedRef.current = modified;
  useEffect(() => {
    setNative(saveFolderSupported());
    let dead = false;
    let stop: (() => void) | undefined;
    const open = async (f: OpenedFile) => {
      if (modifiedRef.current) saveNowRef.current(); // keep a draft of the file being replaced
      await openBytesRef.current(() => readOpenedFile(f), f.name);
    };
    void (async () => {
      const first = await takePendingFile();
      if (first && !dead) await open(first);
      const off = await onFileOpened((f) => void open(f));
      if (dead) off();
      else stop = off;
    })();
    return () => {
      dead = true;
      stop?.();
    };
  }, []);

  const preparingSearch = !!file && hasFieldQuery({ formId: filterId, editorId: filterEdid, name: filterName }) && indexedFile !== file;

  const breadcrumb: string[] = [];
  if (file && selected) {
    for (let g: EspGroup | null = selected.parent; g; g = g.parent) breadcrumb.unshift(describeGroup(g));
    breadcrumb.unshift(file.name);
    const e = getEditorId(selected);
    breadcrumb.push(selected.type === "TES4" ? "File Header" : `${hex8(selected.formId)}${e ? ` <${e}>` : ""}`);
  }

  return (
    <div className="flex min-h-screen flex-col lg:h-screen">
      <header className="flex flex-wrap items-center gap-3 bg-card px-4 pb-1 pt-[max(0.5rem,env(safe-area-inset-top))]">
        <h1 className="font-display text-lg tracking-wide text-primary">
          {APP_TITLE}
        </h1>
        {file && (
          <span className="max-w-full truncate font-mono text-xs text-muted-foreground">
            {countRecords(file.nodes).toLocaleString()} records
            {edition === "SE" && " · Special Edition plugin"}
            {info.masters.length > 0 && ` · masters: ${info.masters.join(", ")}`}
            {modified && <span className="ml-2 text-modified">● unsaved changes</span>}
            {draftNote && <span className="ml-2">· {draftNote}</span>}
          </span>
        )}
      </header>
      {/* Only the buttons stay pinned while the page scrolls; the title and status line scroll away. */}
      <div className="sticky top-0 z-30 border-b bg-card px-4 pb-2 pt-[max(0.5rem,env(safe-area-inset-top))]">
        <div className="flex flex-wrap justify-end gap-2">
          <Button variant="ghost" size="icon" className="size-8" onClick={() => setAboutOpen(true)} aria-label="About and credits">
            <Info />
          </Button>
          <Button variant="ghost" size="icon" className="size-8" onClick={undo} disabled={!file || !history.canUndo} aria-label="Undo" title={history.undoLabel ? `Undo: ${history.undoLabel}` : "Undo"}>
            <Undo2 />
          </Button>
          <Button variant="ghost" size="icon" className="size-8" onClick={redo} disabled={!file || !history.canRedo} aria-label="Redo" title={history.redoLabel ? `Redo: ${history.redoLabel}` : "Redo"}>
            <Redo2 />
          </Button>
          <Button variant="ghost" size="icon" className="size-8" onClick={() => setChangesOpen(true)} disabled={!file} aria-label="Review your changes" title="Review your changes">
            <ListChecks />
          </Button>
          <Button variant="ghost" size="icon" className="size-8" onClick={() => setBulkOpen(true)} disabled={!file} aria-label="Bulk edit" title="Change one number in many records at once">
            <SlidersHorizontal />
          </Button>
          <Button variant="ghost" size="icon" className="size-8" onClick={() => setCheckOpen(true)} disabled={!file} aria-label="Check plugin" title="Check for missing masters and records">
            <ShieldCheck />
          </Button>
          <Button variant="ghost" size="icon" className="size-8" onClick={() => setScriptsOpen(true)} disabled={!file} aria-label="Scripts" title="List the Papyrus scripts this plugin uses">
            <FileCode />
          </Button>
          <Button variant="ghost" size="icon" className="size-8" onClick={() => setCompareOpen(true)} disabled={!file} aria-label="Compare plugins" title="Compare with a master or another version">
            <GitCompare />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="size-8" disabled={!file} aria-label="More tools" title="New record, file header, plugin health, load order">
                <Wrench />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onSelect={() => {
                  setCopySource(null);
                  setNewOpen(true);
                }}
              >
                New record…
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setHeaderOpen(true)}>File header…</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setHealthOpen(true)}>Plugin health (ESL, duplicates)…</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setOrderOpen(true)}>Load order conflicts…</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          {native && (
            <Button variant="ghost" size="icon" className="size-8" onClick={() => setFolderOpen(true)} aria-label="Save folder" title="Choose where files are saved">
              <FolderCog />
            </Button>
          )}
          <input
            ref={inputRef}
            type="file"
            accept=".esp,.esm,.esl,application/octet-stream"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void openFile(f);
              e.target.value = "";
            }}
          />
          <Button variant="secondary" size="sm" onClick={() => inputRef.current?.click()} disabled={loading}>
            <FolderOpen /> {loading ? "Opening…" : "Open"}
          </Button>
          <Button variant={edition === "SE" ? "default" : "secondary"} size="sm" onClick={() => setConvertOpen(true)} disabled={!file} title="Make a Legendary Edition copy of a Special Edition plugin">
            <ArrowLeftRight /> To LE
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setExtractOpen(true)} disabled={!file} title="Save only the records you changed as a new plugin">
            <PackageOpen /> Extract
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setMergeOpen(true)} title="Combine several plugins into one new plugin">
            <GitMerge /> Merge
          </Button>
          <Button size="sm" onClick={save} disabled={!file}>
            <Download /> Save
          </Button>
        </div>
      </div>

      {saveFeedback && (
        <div
          role={saveFeedback.failed ? "alert" : "status"}
          className={`flex items-start gap-2 border-b px-4 py-3 text-sm ${saveFeedback.failed ? "border-destructive bg-destructive/15" : "bg-muted"}`}
        >
          {saveFeedback.failed ? <AlertCircle className="mt-0.5 size-4 shrink-0 text-destructive" /> : <Download className="mt-0.5 size-4 shrink-0 text-primary" />}
          <div className="min-w-0 flex-1 break-words">
            <p className="font-medium">{saveFeedback.failed ? "Download failed" : saveFeedback.savedTo ? "Saved" : "Download requested"} — {saveFeedback.filename}</p>
            <p className="mt-1 text-muted-foreground">
              {saveFeedback.failed
                ? `The download could not be started. Your edits are still here. ${saveFeedback.detail ?? ""}`
                : saveFeedback.savedTo
                  ? `Saved to ${saveFeedback.savedTo} on your device. Your edits are still here.`
                  : "Check your browser’s Downloads or Android download notification to confirm it completed. This browser cannot confirm that the file reached your device; your edits are still here."}
            </p>
            {!saveFeedback.failed && saveFeedback.backup && <p className="mt-1 text-muted-foreground">The original was backed up to {saveFeedback.backup}.</p>}
            {!saveFeedback.failed && saveFeedback.backupError && (
              <p className="mt-1 text-destructive">The original could not be backed up ({saveFeedback.backupError}). The edited file was saved anyway.</p>
            )}
            <Button variant="secondary" size="sm" className="mt-2" onClick={save}>
              <Download /> Try download again
            </Button>
          </div>
          <Button variant="ghost" size="icon" className="shrink-0" onClick={() => setSaveFeedback(null)} aria-label="Dismiss download status">
            <X className="size-4" />
          </Button>
        </div>
      )}

      {pendingDraft && (
        <div role="status" className="flex flex-wrap items-center gap-2 border-b bg-muted px-4 py-3 text-sm">
          <span className="min-w-0 flex-1">
            Unsaved changes from {new Date(pendingDraft.savedAt).toLocaleString()} were found for this file ({pendingDraft.records.length} edited
            {pendingDraft.deleted.length ? `, ${pendingDraft.deleted.length} deleted` : ""}).
          </span>
          <Button size="sm" onClick={restoreDraft}>Restore</Button>
          <Button size="sm" variant="secondary" onClick={discardDraft}>Discard</Button>
        </div>
      )}

      {file && (
        <div className="truncate border-b bg-muted px-4 py-1 font-mono text-xs text-muted-foreground" title={breadcrumb.join(" \\ ")}>
          {breadcrumb.length ? breadcrumb.join(" \\ ") : file.name}
        </div>
      )}

      {error && (
        <div className="flex items-start gap-2 border-b border-destructive bg-destructive/15 px-4 py-2 text-sm">
          <span className="flex-1">{error}</span>
          <button onClick={() => setError(null)} aria-label="Dismiss">
            <X className="size-4" />
          </button>
        </div>
      )}

      {!file ? (
        <div className="flex flex-1 items-center justify-center p-6">
          <div
            className="w-full max-w-md rounded-lg border border-dashed p-10 text-center"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              const f = e.dataTransfer.files[0];
              if (f) void openFile(f);
            }}
          >
            <p className="font-display text-xl text-primary">Open a plugin</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Drop a .esp or .esm file here, or pick one. It never leaves your device.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
              <Button onClick={() => inputRef.current?.click()} disabled={loading}>
                <FolderOpen /> {loading ? "Opening…" : "Choose file"}
              </Button>
              <Button variant="secondary" onClick={() => setMergeOpen(true)}>
                <GitMerge /> Merge plugins
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[minmax(360px,460px)_1fr]">
          <aside className="flex min-h-0 flex-col border-b lg:border-r lg:border-b-0">
            {info.localized && (
              <div className="border-b px-3 py-1.5 text-xs text-muted-foreground">
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span>{strings ? `Names loaded (${strings.size.toLocaleString()} strings)` : "Names are stored in separate strings files (pick them, or Skyrim - Interface.bsa)."}</span>
                  <button className="font-medium text-primary underline underline-offset-2" onClick={() => stringsInputRef.current?.click()}>
                    {strings ? "Add files" : "Load strings files"}
                  </button>
                  {strings && (
                    <button className="underline underline-offset-2" onClick={forgetStrings}>
                      Forget
                    </button>
                  )}
                </div>
                {stringsMsg && <p className="mt-1 break-words">{stringsMsg}</p>}
                <input
                  ref={stringsInputRef}
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    void loadStringFiles(Array.from(e.target.files ?? []));
                    e.target.value = "";
                  }}
                />
              </div>
            )}
            {preparingSearch && <p className="border-b px-3 py-1 text-xs text-muted-foreground">Preparing search… large plugins take a moment the first time.</p>}
            <div className={`${TREE_COLS} border-b bg-muted px-2 py-1 text-xs font-medium text-muted-foreground`}>
              <SortHeader label="FormID" column="formId" sort={sort} onSort={(c) => setSort((cur) => nextSort(cur, c))} className="pl-5" />
              <SortHeader label="EditorID" column="editorId" sort={sort} onSort={(c) => setSort((cur) => nextSort(cur, c))} />
              <SortHeader label="Name" column="name" sort={sort} onSort={(c) => setSort((cur) => nextSort(cur, c))} />
            </div>
            <div role="search" className={`${TREE_COLS} border-b px-2 py-1.5`}>
              <Input
                type="search"
                enterKeyHint="search"
                autoCapitalize="characters"
                autoCorrect="off"
                spellCheck={false}
                aria-label="Filter by FormID"
                placeholder="FormID"
                value={filterId}
                onChange={(e) => setFilterId(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLElement).blur()}
                className="h-8 min-w-0 px-2 font-mono text-xs"
              />
              <Input
                type="search"
                enterKeyHint="search"
                autoCorrect="off"
                spellCheck={false}
                aria-label="Filter by Editor ID"
                placeholder="EditorID"
                value={filterEdid}
                onChange={(e) => setFilterEdid(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLElement).blur()}
                className="h-8 min-w-0 px-2 text-xs"
              />
              <Input
                type="search"
                enterKeyHint="search"
                autoCorrect="off"
                spellCheck={false}
                aria-label="Filter by Name"
                placeholder="Name"
                value={filterName}
                onChange={(e) => setFilterName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLElement).blur()}
                className="h-8 min-w-0 px-2 text-xs"
              />
            </div>
            <div className="max-h-[45vh] flex-1 overflow-auto py-1 lg:max-h-none">
              {results ? (
                <>
                  <div className="flex items-center justify-between px-3 py-1 text-xs text-muted-foreground">
                    <span>{results.length >= MAX_RESULTS ? `First ${MAX_RESULTS} matches` : `${results.length} matches`}</span>
                    <button
                      onClick={() => {
                        setResults(null);
                        setFilterId("");
                        setFilterEdid("");
                        setFilterName("");
                      }}
                      className="text-primary hover:underline"
                    >
                      Clear filter
                    </button>
                  </div>
                  {(orderedResults ?? results).slice(0, shown).map((r) => (
                    <RecordRow
                      key={r.uid}
                      record={r}
                      depth={-1}
                      selected={selected === r}
                      localized={info.localized}
                      showType
                      onSelect={() => select(r, true)}
                    />
                  ))}
                  {results.length > shown && (
                    <div className="px-3 py-2">
                      <Button variant="secondary" size="sm" onClick={() => setShown(shown + PAGE_SIZE * 2)}>
                        Show more ({results.length - shown} left)
                      </Button>
                    </div>
                  )}
                  {results.length === 0 && (
                    <p className="px-3 py-4 text-sm text-muted-foreground">
                      Nothing matches. Every box you fill in has to match, so try fewer or shorter words, or clear one of the boxes.
                    </p>
                  )}
                </>
              ) : (
                <RecordTree
                  nodes={file.nodes}
                  depth={0}
                  expanded={expanded}
                  selected={selected}
                  localized={info.localized}
                  sort={sort}
                  version={rev}
                  onToggle={toggle}
                  onSelect={(r) => select(r)}
                />
              )}
            </div>
          </aside>
          <main ref={panelRef} className="min-w-0 overflow-auto">
            {selected ? (
              <RecordFinderContext.Provider value={findRecords}>
              <RecordView
                key={selected.uid}
                file={file}
                record={selected}
                ctx={ctx}
                history={history}
                onChange={changed}
                onCopy={() => {
                  setCopySource(selected);
                  setNewOpen(true);
                }}
                onDeleted={() => {
                  setSelected(null);
                  setResults((res) => res?.filter((r) => r !== selected) ?? null);
                  changed({ reindex: true });
                }}
              />
              </RecordFinderContext.Provider>
            ) : (
              <p className="p-6 text-sm text-muted-foreground">Select a record to view and edit it.</p>
            )}
          </main>
        </div>
      )}
      <UpdateDialog open={update.release !== null && !aboutOpen && !setupOpen} release={update.release} onLater={update.later} />
      <AboutDialog
        open={aboutOpen}
        onOpenChange={setAboutOpen}
        onSetup={() => {
          setAboutOpen(false);
          setSetupOpen(true);
        }}
      />
      <SetupDialog
        open={setupOpen && !aboutOpen}
        onOpenChange={(o) => {
          setSetupOpen(o);
          if (!o) markSetupDone();
        }}
      />
      {file && (
        <ChangesDialog open={changesOpen} onOpenChange={setChangesOpen} file={file} ctx={ctx} rev={rev} onRevert={revert} onGoTo={(r) => select(r, true)} />
      )}
      {file && <BulkEditDialog open={bulkOpen} onOpenChange={setBulkOpen} file={file} history={history} localized={info.localized} onApplied={() => changed()} />}
      {file && <ExtractDialog open={extractOpen} onOpenChange={setExtractOpen} file={file} selected={selected} />}
      {file && <ConvertDialog open={convertOpen} onOpenChange={setConvertOpen} file={file} />}
      {file && <CheckDialog open={checkOpen} onOpenChange={setCheckOpen} file={file} onGoTo={(r) => select(r, true)} />}
      {file && <ScriptsDialog open={scriptsOpen} onOpenChange={setScriptsOpen} file={file} onGoTo={(r) => select(r, true)} />}
      {file && <CompareDialog open={compareOpen} onOpenChange={setCompareOpen} file={file} history={history} onGoTo={(r) => select(r, true)} onRemoved={() => changed({ reindex: true })} />}
      {file && <NewRecordDialog open={newOpen} onOpenChange={setNewOpen} file={file} history={history} source={copySource} onCreated={created} />}
      {file && <HeaderDialog open={headerOpen} onOpenChange={setHeaderOpen} file={file} history={history} onApplied={() => changed()} />}
      {file && <HealthDialog open={healthOpen} onOpenChange={setHealthOpen} file={file} history={history} onGoTo={(r) => select(r, true)} onApplied={() => changed()} />}
      {file && <LoadOrderDialog open={orderOpen} onOpenChange={setOrderOpen} file={file} onGoTo={(r) => select(r, true)} />}
      <MergeDialog open={mergeOpen} onOpenChange={setMergeOpen} file={file} />
      <SaveFolderDialog open={folderOpen} onOpenChange={setFolderOpen} />
    </div>
  );
}

/** A clickable column title: click to sort, again to reverse, once more to go back to the file order. */
function SortHeader({
  label,
  column,
  sort,
  onSort,
  className,
}: {
  label: string;
  column: SortColumn;
  sort: SortState | null;
  onSort: (column: SortColumn) => void;
  className?: string;
}) {
  const active = sort?.column === column ? sort : null;
  return (
    <button
      type="button"
      onClick={() => onSort(column)}
      aria-sort={active ? (active.dir === "asc" ? "ascending" : "descending") : "none"}
      title={`Sort by ${label}`}
      className={`flex min-w-0 items-center gap-1 text-left hover:text-foreground ${active ? "text-primary" : ""} ${className ?? ""}`}
    >
      <span className="truncate">{label}</span>
      {active && (active.dir === "asc" ? <ArrowUp className="size-3 shrink-0" /> : <ArrowDown className="size-3 shrink-0" />)}
    </button>
  );
}
